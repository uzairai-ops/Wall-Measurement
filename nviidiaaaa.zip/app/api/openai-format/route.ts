import { type NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

interface QAData {
  question: string;
  answer: string;
}

interface FormatRequest {
  qaData: QAData[];
}

export async function POST(request: NextRequest) {
  try {
    const { qaData }: FormatRequest = await request.json();

    if (!qaData || !Array.isArray(qaData)) {
      return NextResponse.json(
        { error: "QA data is required" },
        { status: 400 }
      );
    }

    const qaText = qaData
      .map(
        (item, index) =>
          `Q${index + 1}: ${item.question}\nA${index + 1}: ${item.answer}`
      )
      .join("\n\n");

    const prompt = `Based on the following question-answer pairs from construction media analysis, extract and format all measurable dimensions and measurements in a clear, organized format.

${qaText}

Please format the final result as clean, organized measurements like:

ROOM DIMENSIONS:
- Length: X feet
- Width: Y feet  
- Height: Z feet
- Area: X sq ft

WALL MEASUREMENTS:
- Wall 1 Height: X feet
- Wall 1 Length: Y feet
- Wall 2 Height: X feet
- Wall 2 Length: Y feet

DOOR/WINDOW DIMENSIONS:
- Door Height: X feet
- Door Width: Y feet
- Window Height: X feet
- Window Width: Y feet

FLOOR MEASUREMENTS:
- Floor Area: X by Y feet
- Total Square Footage: Z sq ft

Only include measurements that can be reasonably determined from the analysis. If no specific measurements are available, indicate "Measurements not clearly visible" for that category.

Focus on providing concrete numbers where possible, and organize by construction elements (rooms, walls, floors, doors, windows, etc.).`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content:
            "You are a construction measurement specialist. Format measurement data clearly and professionally, focusing on concrete dimensions and measurements.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      temperature: 0.1,
      max_tokens: 1500,
    });

    const result =
      completion.choices[0]?.message?.content ||
      "No measurements could be determined from the analysis.";

    return NextResponse.json({ result });
  } catch (error) {
    console.error("OpenAI format error:", error);
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : "Failed to format results",
      },
      { status: 500 }
    );
  }
}
